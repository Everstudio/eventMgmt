export const createEventValidationSchema = {
  name: {
    isString: {
      errorMessage: "Event name must be a string",
    },
    notEmpty: {
      errorMessage: "Event name is required",
    },
  },
  description: {
    isString: {
      errorMessage: "Event description must be a string",
    },
    optional: true,
  },
  location: {
    isString: {
      errorMessage: "Event location must be a string",
    },
    optional: true,
  },
  start_date: {
    isISO8601: {
      errorMessage: "Start date must be a valid date",
    },
    notEmpty: {
      errorMessage: "Start date is required",
    },
  },
  end_date: {
    isISO8601: {
      errorMessage: "End date must be a valid date",
    },
    notEmpty: {
      errorMessage: "End date is required",
    },
  },
  is_recurring: {
    isBoolean: {
      errorMessage: "Is recurring must be a boolean",
    },
    optional: true,
  },
  recurrence_pattern: {
    isString: {
      errorMessage: "Recurrence pattern must be a string",
    },
    optional: true,
  },
};

export const createEventCategoryValidationSchema = {
  name: {
    isString: {
      errorMessage: "Event category name must be a string",
    },
    notEmpty: {
      errorMessage: "Event category name is required",
    },
  },
  description: {
    isString: {
      errorMessage: "Event category description must be a string",
    },
    optional: true,
  },
};
