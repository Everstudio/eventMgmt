import { Router } from "express";
import eventRouter from "./events.mjs";

const router = Router();

router.use(eventRouter);

export default router;
