import pool from "../configs/db.mjs";

class AttendeesModel {
  constructor() {
    this.pool = pool;
  }

  //create attendee
  async createAttendee(attendee) {
    try {
      const [result] = await this.pool.query("INSERT INTO attendees SET ?", [attendee]);
      return result.insertId;
    } catch (error) {
      throw new Error(`Error creating attendee: ${error.message}`);
    }
  }

  //get all attendees
  async getAttendees() {
    try {
      const [attendees] = await this.pool.query("SELECT * FROM attendees");
      return attendees;
    } catch (error) {
      throw new Error(`Error retrieving attendees: ${error.message}`);
    }
  }

  //get attendee by id
  async getAttendeeById(id) {
    try {
      const [attendee] = await this.pool.query("SELECT * FROM attendees WHERE id = ?", [parseInt(id)]);
      return attendee[0] || null;
    } catch (error) {
      throw new Error(`Error retrieving attendee by ID: ${error.message}`);
    }
  }

  //get all attendees by registration id
  async getAttendeesByRegistrationId(registration_id) {
    try {
      const [attendees] = await this.pool.query("SELECT * FROM attendees WHERE registration_id = ?", [parseInt(registration_id)]);
      return attendees;
    } catch (error) {
      throw new Error(`Error retrieving attendees by registration ID: ${error.message}`);
    }
  }

  //update attendee
  async updateAttendee(id, attendee) {
    try {
      const [result] = await this.pool.query("UPDATE attendees SET ? WHERE id = ?", [attendee, parseInt(id)]);
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error updating attendee: ${error.message}`);
    }
  }

  //update attendee status
  async updateAttendeesStatus(registrationId, status) {
    try {
      const [result] = await this.pool.query("UPDATE attendees SET status = ? WHERE registration_id = ?", [status, parseInt(registrationId)]);
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error updating attendee status: ${error.message}`);
    }
  }

  //update attendee qr code
  async updateAttendeeQR(id, qr_code) {
    try {
      const [result] = await this.pool.query("UPDATE attendees SET qr_code = ? WHERE id = ?", [qr_code, parseInt(id)]);
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error updating attendee QR code: ${error.message}`);
    }
  }

  //delete attendee
  async deleteAttendee(id) {
    try {
      const [result] = await this.pool.query("DELETE FROM attendees WHERE id = ?", [parseInt(id)]);
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error deleting attendee: ${error.message}`);
    }
  }


  //get attendees e-ticket
  async getAttendeesETicket(query) {
    const registrationId = query.id;
    const unique_code = query.e;

    //retrieve all the attendees with the registration id and unique code
    try {
      const [attendees] = await this.pool.query("SELECT * FROM attendees WHERE registration_id = ? AND unique_code = ?", [parseInt(registrationId), unique_code]);
      const registration = await this.pool.query("SELECT * FROM registrations WHERE id = ?", [parseInt(registrationId)]);
      const event = await this.pool.query("SELECT * FROM events WHERE id = ?", [registration[0][0].event_id]);
      
      //add event name to attendees
      attendees.forEach((attendee) => {
        attendee.event_name = event[0][0].name;
      });
      
      return attendees;
    } catch (error) {
      throw new Error(`Error retrieving attendees e-ticket: ${error.message}`);
    }

  }

}

export default AttendeesModel;
